from distutils.core import setup
setup(name = "neocane",
      version = "0.1",
      description = "Support library for UDOO NEO board",
      author = "Giovanni Burresi",
      author_email = "giovanniburresi@gmail.com",
      url = "",
      packages=["neocane"]
      )
